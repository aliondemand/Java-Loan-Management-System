import java.util.*;

class Customer extends Person {
    private String cnic;
    private double monthlyIncome;
    private int creditScore;
    private List<LoanApplication> applications;

    public Customer(String id, String name, String phone,
                    String email, String cnic,
                    double monthlyIncome, int creditScore) {
        super(id, name, phone, email);
        this.cnic         = cnic;
        this.monthlyIncome = monthlyIncome;
        this.creditScore   = creditScore;
        this.applications  = new ArrayList<>();
    }

    public boolean isEligible(double loanAmount) {
        return (monthlyIncome * 12 * 5 >= loanAmount) && (creditScore >= 600);
    }

    public void addApplication(LoanApplication app) {
        applications.add(app);
    }

    public void updateCreditScore(int delta) {
        creditScore = Math.min(850, Math.max(300, creditScore + delta));
    }

    public String getCnic()           { return cnic; }
    public double getMonthlyIncome()  { return monthlyIncome; }
    public int getCreditScore()       { return creditScore; }
    public List<LoanApplication> getApplications() { return applications; }

    @Override
    public String getRole() { return "Customer"; }

    @Override
    public String toFileString() {
        return getId() + "," + getName() + "," + getPhone() + ","
             + getEmail() + "," + cnic + ","
             + monthlyIncome + "," + creditScore;
    }

    public static Customer fromFileString(String line) {
        String[] p = line.split(",");
        return new Customer(p[0], p[1], p[2], p[3], p[4],
               Double.parseDouble(p[5]), Integer.parseInt(p[6]));
    }
}