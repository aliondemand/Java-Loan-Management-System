class HomeLoan extends Loan {
    private String propertyAddress;

    public HomeLoan(String loanId, double principal,
                    int tenureMonths, String propertyAddress) {
        super(loanId, principal, 9.5, tenureMonths);
        this.propertyAddress = propertyAddress;
    }

    public String getPropertyAddress() { return propertyAddress; }

    @Override public double getMaxAmount() { return 10000000; }
    @Override public double getMinIncome() { return 50000; }
    @Override public String getLoanType()  { return "Home Loan"; }

    @Override
    public String toFileString() {
        return getLoanId() + ",HOME," + getPrincipal()
             + "," + getTenureMonths() + "," + propertyAddress;
    }
}