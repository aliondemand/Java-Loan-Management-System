import java.util.Date;

class LoanApplication {
    private String applicationId;
    private Customer customer;
    private Loan loan;
    private String status;
    private String remarks;
    private Date applicationDate;
    private int paidInstallments;

    public LoanApplication(String applicationId,
                           Customer customer, Loan loan) {
        this.applicationId  = applicationId;
        this.customer       = customer;
        this.loan           = loan;
        this.status         = "PENDING";
        this.remarks        = "";
        this.applicationDate = new Date();
        this.paidInstallments = 0;
    }

    public void payInstallment() {
        if (paidInstallments < loan.getTenureMonths()) {
            paidInstallments++;
            if (paidInstallments == loan.getTenureMonths())
                status = "CLOSED";
        }
    }

    public double getRemainingBalance() {
        return loan.calculateRemainingBalance(paidInstallments);
    }

    public String getApplicationId()  { return applicationId; }
    public Customer getCustomer()     { return customer; }
    public Loan getLoan()             { return loan; }
    public String getStatus()         { return status; }
    public String getRemarks()        { return remarks; }
    public int getPaidInstallments()  { return paidInstallments; }
    public Date getApplicationDate()  { return applicationDate; }

    public void setStatus(String status)   { this.status = status; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public String toFileString() {
        return applicationId + "," + customer.getId() + ","
             + loan.getLoanId() + "," + status + ","
             + remarks + "," + paidInstallments;
    }
}