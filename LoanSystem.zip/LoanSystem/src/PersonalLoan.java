class PersonalLoan extends Loan {
    private String purpose;

    public PersonalLoan(String loanId, double principal,
                        int tenureMonths, String purpose) {
        super(loanId, principal, 15.5, tenureMonths);
        this.purpose = purpose;
    }

    public String getPurpose() { return purpose; }

    @Override public double getMaxAmount() { return 500000; }
    @Override public double getMinIncome() { return 20000; }
    @Override public String getLoanType()  { return "Personal Loan"; }

    @Override
    public String toFileString() {
        return getLoanId() + ",PERSONAL," + getPrincipal()
             + "," + getTenureMonths() + "," + purpose;
    }
}