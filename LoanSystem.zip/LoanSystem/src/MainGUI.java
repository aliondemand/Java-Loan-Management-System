import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.*;

public class MainGUI extends JFrame {

    private List<Customer>        customers = new ArrayList<>();
    private List<LoanApplication> apps      = new ArrayList<>();

    private LoanOfficer officer = new LoanOfficer(
        "O1", "Ali Hassan", "0300-1234567",
        "ali@bank.com", "EMP001", "Main Branch");

    public MainGUI() {
        setTitle("Loan Management System");
        setSize(820, 680);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Register",          buildRegisterPanel());
        tabs.addTab("Apply for Loan",    buildApplyPanel());
        tabs.addTab("EMI Calculator",    buildEMIPanel());
        tabs.addTab("Schedule",          buildSchedulePanel());
        tabs.addTab("My Applications",   buildMyAppsPanel());
        tabs.addTab("Officer Panel",     buildOfficerPanel());

        add(tabs);
        setVisible(true);
    }

    private JPanel buildRegisterPanel() {
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JTextField nameF   = new JTextField();
        JTextField phoneF  = new JTextField();
        JTextField emailF  = new JTextField();
        JTextField cnicF   = new JTextField();
        JTextField incomeF = new JTextField();
        JTextField scoreF  = new JTextField();
        JTextArea out      = new JTextArea(5, 30);
        out.setEditable(false);

        form.add(new JLabel("Full Name:"));      form.add(nameF);
        form.add(new JLabel("Phone:"));          form.add(phoneF);
        form.add(new JLabel("Email:"));          form.add(emailF);
        form.add(new JLabel("CNIC:"));           form.add(cnicF);
        form.add(new JLabel("Monthly Income:")); form.add(incomeF);
        form.add(new JLabel("Credit Score:"));   form.add(scoreF);

        JButton btn = new JButton("Register");
        btn.addActionListener(e -> {
            try {
                Customer c = new Customer(
                    "C" + (customers.size() + 1),
                    nameF.getText(), phoneF.getText(),
                    emailF.getText(), cnicF.getText(),
                    Double.parseDouble(incomeF.getText()),
                    Integer.parseInt(scoreF.getText())
                );
                customers.add(c);
                FileHandler.saveCustomers(customers);
                out.append("Registered: " + c.getName()
                    + " (ID: " + c.getId() + ")\n");
            } catch (Exception ex) {
                out.append("Error: Fill all fields correctly.\n");
            }
        });

        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        p.add(form, BorderLayout.NORTH);
        p.add(btn,  BorderLayout.CENTER);
        p.add(new JScrollPane(out), BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildApplyPanel() {
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JTextField customerIdF = new JTextField();
        JTextField amountF     = new JTextField();
        JTextField tenureF     = new JTextField();
        JTextField extraF      = new JTextField();
        JComboBox<String> typeBox = new JComboBox<>(
            new String[]{"Home Loan", "Car Loan", "Personal Loan"});
        JTextArea out = new JTextArea(6, 30);
        out.setEditable(false);

        form.add(new JLabel("Customer ID:"));          form.add(customerIdF);
        form.add(new JLabel("Loan Type:"));            form.add(typeBox);
        form.add(new JLabel("Amount:"));               form.add(amountF);
        form.add(new JLabel("Tenure (months):"));      form.add(tenureF);
        form.add(new JLabel("Property / Car / Purpose:")); form.add(extraF);

        JButton btn = new JButton("Submit Application");
        btn.addActionListener(e -> {
            try {
                String cid    = customerIdF.getText().trim();
                double amount = Double.parseDouble(amountF.getText());
                int tenure    = Integer.parseInt(tenureF.getText());
                String extra  = extraF.getText();
                String type   = (String) typeBox.getSelectedItem();

                Customer found = null;
                for (Customer c : customers)
                    if (c.getId().equals(cid)) { found = c; break; }

                if (found == null) {
                    out.append("Customer ID not found.\n"); return;
                }

                String loanId = "L" + (apps.size() + 1);
                Loan loan;
                if (type.equals("Home Loan"))
                    loan = new HomeLoan(loanId, amount, tenure, extra);
                else if (type.equals("Car Loan"))
                    loan = new CarLoan(loanId, amount, tenure, extra, true);
                else
                    loan = new PersonalLoan(loanId, amount, tenure, extra);

                if (!found.isEligible(amount)) {
                    out.append("NOT ELIGIBLE: Low income or credit score.\n");
                    return;
                }

                LoanApplication app = new LoanApplication(
                    "APP" + (apps.size() + 1), found, loan);
                apps.add(app);
                found.addApplication(app);
                FileHandler.saveApplication(app);

                out.append("Application submitted!\n");
                out.append("ID: " + app.getApplicationId() + "\n");
                out.append("Loan: " + loan.getLoanType()
                    + " | Amount: " + amount + "\n");
                out.append(String.format("Monthly EMI: %.2f\n\n",
                    loan.calculateEMI()));

            } catch (Exception ex) {
                out.append("Error: Fill all fields correctly.\n");
            }
        });

        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        p.add(form, BorderLayout.NORTH);
        p.add(btn,  BorderLayout.CENTER);
        p.add(new JScrollPane(out), BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildEMIPanel() {
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JTextField amountF = new JTextField();
        JTextField tenureF = new JTextField();
        JTextField rateF   = new JTextField();
        JTextArea out      = new JTextArea(10, 30);
        out.setEditable(false);
        out.setFont(new Font("Monospaced", Font.PLAIN, 13));

        form.add(new JLabel("Loan Amount:"));      form.add(amountF);
        form.add(new JLabel("Tenure (months):"));  form.add(tenureF);
        form.add(new JLabel("Interest Rate (%):"));form.add(rateF);

        JButton btn = new JButton("Calculate");
        btn.addActionListener(e -> {
            try {
                double amount = Double.parseDouble(amountF.getText());
                int tenure    = Integer.parseInt(tenureF.getText());
                double rate   = Double.parseDouble(rateF.getText());
                double r      = rate / 12 / 100;
                double emi    = (amount * r * Math.pow(1+r, tenure))
                              / (Math.pow(1+r, tenure) - 1);
                double total    = emi * tenure;
                double interest = total - amount;

                out.setText("");
                out.append("=================================\n");
                out.append(String.format("Monthly EMI      : %.2f\n", emi));
                out.append(String.format("Total Payment    : %.2f\n", total));
                out.append(String.format("Total Interest   : %.2f\n", interest));
                out.append(String.format("Interest %%       : %.1f%%\n",
                    (interest / amount) * 100));
                out.append("=================================\n\n");
                out.append(String.format("%-6s %-10s %-10s %-10s %-12s\n",
                    "Month", "EMI", "Principal", "Interest", "Balance"));

                double balance = amount;
                for (int m = 1; m <= Math.min(tenure, 12); m++) {
                    double ic = balance * r;
                    double pc = emi - ic;
                    balance  -= pc;
                    out.append(String.format("%-6d %-10.2f %-10.2f %-10.2f %-12.2f\n",
                        m, emi, pc, ic, Math.max(0, balance)));
                }
                if (tenure > 12)
                    out.append("... (showing first 12 months)\n");

            } catch (Exception ex) {
                out.append("Error: Enter valid numbers.\n");
            }
        });

        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        p.add(form, BorderLayout.NORTH);
        p.add(btn,  BorderLayout.CENTER);
        p.add(new JScrollPane(out), BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildSchedulePanel() {
        JPanel top = new JPanel(new FlowLayout());

        JTextField amountF = new JTextField(10);
        JTextField tenureF = new JTextField(6);
        JTextField rateF   = new JTextField(6);

        String[] cols = {"Month", "EMI", "Principal", "Interest", "Balance"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);

        top.add(new JLabel("Amount:"));  top.add(amountF);
        top.add(new JLabel("Tenure:"));  top.add(tenureF);
        top.add(new JLabel("Rate %:"));  top.add(rateF);

        JButton btn = new JButton("Generate Schedule");
        btn.addActionListener(e -> {
            try {
                double amount = Double.parseDouble(amountF.getText());
                int tenure    = Integer.parseInt(tenureF.getText());
                double rate   = Double.parseDouble(rateF.getText());
                double r      = rate / 12 / 100;
                double emi    = (amount * r * Math.pow(1+r, tenure))
                              / (Math.pow(1+r, tenure) - 1);
                double balance = amount;
                model.setRowCount(0);

                for (int m = 1; m <= tenure; m++) {
                    double ic = balance * r;
                    double pc = emi - ic;
                    balance  -= pc;
                    model.addRow(new Object[]{
                        m,
                        String.format("%.2f", emi),
                        String.format("%.2f", pc),
                        String.format("%.2f", ic),
                        String.format("%.2f", Math.max(0, balance))
                    });
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Enter valid numbers.");
            }
        });

        top.add(btn);

        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        p.add(top, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        return p;
    }

    private JPanel buildMyAppsPanel() {
        String[] cols = {"App ID", "Customer", "Loan Type",
                         "Amount", "EMI", "Paid", "Status"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);

        JButton refreshBtn = new JButton("Refresh");
        JButton payBtn     = new JButton("Pay Installment");

        refreshBtn.addActionListener(e -> {
            model.setRowCount(0);
            for (LoanApplication app : apps) {
                model.addRow(new Object[]{
                    app.getApplicationId(),
                    app.getCustomer().getName(),
                    app.getLoan().getLoanType(),
                    String.format("%.0f", app.getLoan().getPrincipal()),
                    String.format("%.2f", app.getLoan().calculateEMI()),
                    app.getPaidInstallments() + "/"
                        + app.getLoan().getTenureMonths(),
                    app.getStatus()
                });
            }
        });

        payBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(null,
                    "Select an application first."); return;
            }
            LoanApplication app = apps.get(row);
            if (!app.getStatus().equals("APPROVED")) {
                JOptionPane.showMessageDialog(null,
                    "Loan must be APPROVED first."); return;
            }
            app.payInstallment();
            JOptionPane.showMessageDialog(null,
                String.format("Installment paid!\nPaid: %d / %d\nRemaining Balance: %.2f",
                    app.getPaidInstallments(),
                    app.getLoan().getTenureMonths(),
                    app.getRemainingBalance()));
            refreshBtn.doClick();
        });

        JPanel btnRow = new JPanel(new FlowLayout());
        btnRow.add(refreshBtn);
        btnRow.add(payBtn);

        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        p.add(btnRow, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        return p;
    }

    private JPanel buildOfficerPanel() {
        String[] cols = {"App ID", "Customer", "Loan Type",
                         "Amount", "Credit Score", "Status"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);

        JButton refreshBtn = new JButton("Refresh");
        JButton approveBtn = new JButton("Approve");
        JButton rejectBtn  = new JButton("Reject");
        JLabel statsLabel  = new JLabel(officer.getStats());

        refreshBtn.addActionListener(e -> {
            model.setRowCount(0);
            for (LoanApplication app : apps) {
                model.addRow(new Object[]{
                    app.getApplicationId(),
                    app.getCustomer().getName(),
                    app.getLoan().getLoanType(),
                    String.format("%.0f", app.getLoan().getPrincipal()),
                    app.getCustomer().getCreditScore(),
                    app.getStatus()
                });
            }
            statsLabel.setText(officer.getStats());
        });

        approveBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) return;
            officer.approveLoan(apps.get(row));
            JOptionPane.showMessageDialog(null, "Loan APPROVED for "
                + apps.get(row).getCustomer().getName());
            refreshBtn.doClick();
        });

        rejectBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) return;
            String reason = JOptionPane.showInputDialog("Rejection reason:");
            if (reason != null && !reason.isEmpty()) {
                officer.rejectLoan(apps.get(row), reason);
                refreshBtn.doClick();
            }
        });

        JPanel btnRow = new JPanel(new FlowLayout());
        btnRow.add(refreshBtn);
        btnRow.add(approveBtn);
        btnRow.add(rejectBtn);
        btnRow.add(statsLabel);

        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        p.add(btnRow, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        return p;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainGUI());
    }
}