class CarLoan extends Loan {
    private String carModel;
    private boolean isNew;

    public CarLoan(String loanId, double principal,
                   int tenureMonths, String carModel, boolean isNew) {
        super(loanId, principal, isNew ? 12.0 : 15.0, tenureMonths);
        this.carModel = carModel;
        this.isNew    = isNew;
    }

    public String getCarModel() { return carModel; }
    public boolean isNew()      { return isNew; }

    @Override public double getMaxAmount() { return 3000000; }
    @Override public double getMinIncome() { return 30000; }
    @Override public String getLoanType()  { return "Car Loan"; }

    @Override
    public String toFileString() {
        return getLoanId() + ",CAR," + getPrincipal()
             + "," + getTenureMonths() + "," + carModel + "," + isNew;
    }
}