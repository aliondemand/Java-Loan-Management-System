import java.io.*;
import java.util.*;

class FileHandler {
    static final String CUSTOMERS_FILE    = "data/customers.txt";
    static final String OFFICERS_FILE     = "data/officers.txt";
    static final String APPLICATIONS_FILE = "data/applications.txt";

    public static void saveCustomers(List<Customer> list) throws IOException {
        BufferedWriter w = new BufferedWriter(new FileWriter(CUSTOMERS_FILE));
        for (Customer c : list) { w.write(c.toFileString()); w.newLine(); }
        w.close();
    }

    public static List<Customer> loadCustomers() throws IOException {
        List<Customer> list = new ArrayList<>();
        BufferedReader r = new BufferedReader(new FileReader(CUSTOMERS_FILE));
        String line;
        while ((line = r.readLine()) != null)
            list.add(Customer.fromFileString(line));
        r.close();
        return list;
    }

    public static void saveOfficers(List<LoanOfficer> list) throws IOException {
        BufferedWriter w = new BufferedWriter(new FileWriter(OFFICERS_FILE));
        for (LoanOfficer o : list) { w.write(o.toFileString()); w.newLine(); }
        w.close();
    }

    public static List<LoanOfficer> loadOfficers() throws IOException {
        List<LoanOfficer> list = new ArrayList<>();
        BufferedReader r = new BufferedReader(new FileReader(OFFICERS_FILE));
        String line;
        while ((line = r.readLine()) != null)
            list.add(LoanOfficer.fromFileString(line));
        r.close();
        return list;
    }

    public static void saveApplication(LoanApplication app) throws IOException {
        BufferedWriter w = new BufferedWriter(
                new FileWriter(APPLICATIONS_FILE, true));
        w.write(app.toFileString());
        w.newLine();
        w.close();
    }
}