class LoanOfficer extends Person {
    private String employeeId;
    private String branch;
    private int totalApproved;
    private int totalRejected;

    public LoanOfficer(String id, String name, String phone,
                       String email, String employeeId, String branch) {
        super(id, name, phone, email);
        this.employeeId    = employeeId;
        this.branch        = branch;
        this.totalApproved = 0;
        this.totalRejected = 0;
    }

    public void approveLoan(LoanApplication app) {
        app.setStatus("APPROVED");
        app.getCustomer().updateCreditScore(+10);
        totalApproved++;
    }

    public void rejectLoan(LoanApplication app, String reason) {
        app.setStatus("REJECTED");
        app.setRemarks(reason);
        app.getCustomer().updateCreditScore(-5);
        totalRejected++;
    }

    public String getStats() {
        return "Approved: " + totalApproved + " | Rejected: " + totalRejected;
    }

    public String getEmployeeId() { return employeeId; }
    public String getBranch()     { return branch; }

    @Override
    public String getRole() { return "Loan Officer"; }

    @Override
    public String toFileString() {
        return getId() + "," + getName() + "," + getPhone() + ","
             + getEmail() + "," + employeeId + "," + branch;
    }

    public static LoanOfficer fromFileString(String line) {
        String[] p = line.split(",");
        return new LoanOfficer(p[0], p[1], p[2], p[3], p[4], p[5]);
    }
}