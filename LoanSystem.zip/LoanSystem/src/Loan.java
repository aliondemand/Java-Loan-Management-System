abstract class Loan {
    private String loanId;
    private double principal;
    private double interestRate;
    private int tenureMonths;

    public Loan(String loanId, double principal,
                double interestRate, int tenureMonths) {
        this.loanId        = loanId;
        this.principal     = principal;
        this.interestRate  = interestRate;
        this.tenureMonths  = tenureMonths;
    }

    public double calculateEMI() {
        double r = interestRate / 12 / 100;
        return (principal * r * Math.pow(1 + r, tenureMonths))
             / (Math.pow(1 + r, tenureMonths) - 1);
    }

    public double calculateTotalPayment()  { return calculateEMI() * tenureMonths; }
    public double calculateTotalInterest() { return calculateTotalPayment() - principal; }

    public double calculateRemainingBalance(int paidMonths) {
        double r = interestRate / 12 / 100;
        return principal * Math.pow(1 + r, paidMonths)
             - calculateEMI() * ((Math.pow(1 + r, paidMonths) - 1) / r);
    }

    public String getLoanId()       { return loanId; }
    public double getPrincipal()    { return principal; }
    public double getInterestRate() { return interestRate; }
    public int getTenureMonths()    { return tenureMonths; }

    public abstract double getMaxAmount();
    public abstract double getMinIncome();
    public abstract String getLoanType();
    public abstract String toFileString();
}